This directory contains patches that replace Valve's broken file picker with ours.
