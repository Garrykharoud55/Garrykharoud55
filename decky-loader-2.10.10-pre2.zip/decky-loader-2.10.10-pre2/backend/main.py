# This file is needed to make the relative imports in src/ work properly.
if __name__ == "__main__":
    from src.main import main
    main()
